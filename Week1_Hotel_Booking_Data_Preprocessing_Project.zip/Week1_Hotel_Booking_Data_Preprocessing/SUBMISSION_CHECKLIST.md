# Submission Checklist
- [ ] Run `pip install -r requirements.txt`
- [ ] Run `python week1_hotel_cleaning.py`
- [ ] Confirm `data/processed/hotel_bookings_cleaned.csv` exists
- [ ] Review `outputs/quality_report.csv`
- [ ] Review `outputs/outlier_report.csv`
- [ ] Add 4–6 screenshots to the DOCX if your evaluator requires screenshots
- [ ] Replace "Ashutosh Kumar" if a different name is required
- [ ] Submit the DOCX plus code/data files if requested
