# Week 1 — Hotel Booking Data Acquisition, Cleaning & Preprocessing

## Deliverables
- `Week1_Hotel_Booking_Data_Preprocessing_Report.docx` — formatted submission report.
- `week1_hotel_cleaning.py` — complete reproducible Python workflow.
- `requirements.txt` — required packages.
- `README.md` — execution instructions.

## Dataset
Hotel Booking Demand dataset, originally published by Nuno António, Ana de Almeida and Luis Nunes in *Data in Brief* (2019). The source article describes two hotel datasets covering resort and city hotels, with bookings arriving from 1 July 2015 to 31 August 2017. The TidyTuesday project provides a combined CSV copy for educational/reproducible analysis.

## Run
1. Install Python 3.10+.
2. Open a terminal in this project folder.
3. Run:
   `pip install -r requirements.txt`
4. Run:
   `python week1_hotel_cleaning.py`

The script downloads the public CSV, performs quality checks and cleaning, then creates the processed CSV and analysis outputs.

## Important methodology note
Outliers are **flagged rather than automatically deleted**. Extreme values may represent genuine large bookings, long stays or high rates. The report explains why this is safer for downstream analysis.

## Suggested screenshots
After running the script, add screenshots of:
- Jupyter/terminal execution
- `df.info()`
- missing-value report
- outlier report
- before/after quality report
- generated charts
