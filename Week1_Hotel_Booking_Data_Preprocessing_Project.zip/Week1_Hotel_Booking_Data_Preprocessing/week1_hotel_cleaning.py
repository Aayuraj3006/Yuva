"""
Week 1 Task — Data Acquisition, Cleaning and Preprocessing
Dataset: Hotel Booking Demand
Run:
    python week1_hotel_cleaning.py

The script downloads the public TidyTuesday copy of the Hotel Booking Demand
dataset, performs quality checks, cleaning and preprocessing, and writes:
- data/raw/hotels.csv
- data/processed/hotel_bookings_cleaned.csv
- outputs/quality_report.csv
- outputs/summary.txt
- outputs/*.png
"""

from pathlib import Path
import urllib.request
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
RAW_DIR = BASE / "data" / "raw"
PROCESSED_DIR = BASE / "data" / "processed"
OUT_DIR = BASE / "outputs"
for p in (RAW_DIR, PROCESSED_DIR, OUT_DIR):
    p.mkdir(parents=True, exist_ok=True)

DATA_URL = (
    "https://raw.githubusercontent.com/rfordatascience/tidytuesday/"
    "main/data/2020/2020-02-11/hotels.csv"
)
RAW_FILE = RAW_DIR / "hotels.csv"
CLEAN_FILE = PROCESSED_DIR / "hotel_bookings_cleaned.csv"

# 1. DATA ACQUISITION
if not RAW_FILE.exists():
    print("Downloading dataset...")
    urllib.request.urlretrieve(DATA_URL, RAW_FILE)

df = pd.read_csv(RAW_FILE)
print("Initial shape:", df.shape)

# 2. INITIAL EXPLORATION
print("\nColumns:\n", df.columns.tolist())
print("\nData types:\n", df.dtypes)
print("\nDuplicate rows:", df.duplicated().sum())
print("\nMissing values:\n", df.isna().sum().sort_values(ascending=False))
print("\nNumeric summary:\n", df.describe().T)

# Save initial missing-value report
missing = df.isna().sum().reset_index()
missing.columns = ["column", "missing_count"]
missing["missing_pct"] = missing["missing_count"] / len(df) * 100
missing.sort_values("missing_count", ascending=False).to_csv(
    OUT_DIR / "missing_values_before.csv", index=False
)

# 3. DATA TYPE CLEANING
df["reservation_status_date"] = pd.to_datetime(
    df["reservation_status_date"], errors="coerce"
)

# 4. MISSING VALUE HANDLING
# Agent and company are identifiers for intermediaries, and missing means
# the booking is not associated with a recorded agent/company.
df["agent"] = df["agent"].fillna(0)
df["company"] = df["company"].fillna(0)

# Country: preserve the record but explicitly mark unavailable country.
df["country"] = df["country"].fillna("Unknown")

# Children has only a few missing observations. For a count variable,
# zero is a defensible operational interpretation when the related booking
# has no recorded children; this choice should be reviewed if a stricter
# business definition is available.
df["children"] = df["children"].fillna(0)

# 5. CATEGORICAL STANDARDIZATION
# "Undefined" meal is treated as equivalent to SC (self-catering/no meal)
# for analysis because the source documentation describes Undefined/SC as
# no meal package.
df["meal"] = df["meal"].replace({"Undefined": "SC"})

# Undefined distribution channel/market segment are retained as explicit
# categories rather than silently deleting records.
df["distribution_channel"] = df["distribution_channel"].replace(
    {"Undefined": "Unknown"}
)
df["market_segment"] = df["market_segment"].replace(
    {"Undefined": "Unknown"}
)

# Normalize text columns.
text_cols = df.select_dtypes(include="object").columns
for col in text_cols:
    df[col] = df[col].astype(str).str.strip()

# 6. LOGICAL VALIDATION
# Booking counts cannot be negative.
non_negative_cols = [
    "lead_time", "stays_in_weekend_nights", "stays_in_week_nights",
    "adults", "children", "babies", "previous_cancellations",
    "previous_bookings_not_canceled", "booking_changes",
    "days_in_waiting_list", "required_car_parking_spaces",
    "total_of_special_requests"
]
for col in non_negative_cols:
    df.loc[df[col] < 0, col] = np.nan

# ADR (average daily rate) should not be negative.
df.loc[df["adr"] < 0, "adr"] = np.nan

# 7. OUTLIER FLAGGING (IQR)
# Outliers are flagged rather than automatically deleted because extreme
# hotel bookings can be genuine business observations.
outlier_rows = []
for col in ["lead_time", "adr", "stays_in_week_nights",
            "stays_in_weekend_nights", "adults", "booking_changes"]:
    q1 = df[col].quantile(0.25)
    q3 = df[col].quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    count = ((df[col] < lower) | (df[col] > upper)).sum()
    outlier_rows.append(
        {"column": col, "Q1": q1, "Q3": q3, "IQR": iqr,
         "lower_bound": lower, "upper_bound": upper,
         "outlier_count": int(count)}
    )

outlier_report = pd.DataFrame(outlier_rows)
outlier_report.to_csv(OUT_DIR / "outlier_report.csv", index=False)

# 8. FEATURE ENGINEERING FOR ANALYSIS
df["total_nights"] = (
    df["stays_in_weekend_nights"] + df["stays_in_week_nights"]
)
df["total_guests"] = df["adults"] + df["children"] + df["babies"]
df["is_family_booking"] = (
    (df["children"] > 0) | (df["babies"] > 0)
).astype(int)

# Construct arrival date from separate source fields.
df["arrival_date"] = pd.to_datetime(
    df["arrival_date_year"].astype(str) + "-" +
    df["arrival_date_month"] + "-" +
    df["arrival_date_day_of_month"].astype(str),
    errors="coerce"
)

# 9. FINAL QUALITY CHECKS
quality = pd.DataFrame({
    "metric": [
        "rows", "columns", "duplicate_rows", "total_missing_cells",
        "invalid_arrival_dates", "negative_adr"
    ],
    "value": [
        len(df), len(df.columns), int(df.duplicated().sum()),
        int(df.isna().sum().sum()),
        int(df["arrival_date"].isna().sum()),
        int((df["adr"] < 0).sum())
    ]
})
quality.to_csv(OUT_DIR / "quality_report.csv", index=False)

# 10. VISUAL CHECKS
plt.figure(figsize=(9, 5))
df["adr"].clip(upper=df["adr"].quantile(0.99)).hist(bins=40)
plt.title("ADR Distribution After Basic Cleaning (99th Percentile Capped for Plot)")
plt.xlabel("Average Daily Rate")
plt.ylabel("Bookings")
plt.tight_layout()
plt.savefig(OUT_DIR / "adr_distribution.png", dpi=180)
plt.close()

plt.figure(figsize=(9, 5))
df["total_nights"].clip(upper=df["total_nights"].quantile(0.99)).hist(bins=30)
plt.title("Total Nights Distribution")
plt.xlabel("Total Nights")
plt.ylabel("Bookings")
plt.tight_layout()
plt.savefig(OUT_DIR / "total_nights_distribution.png", dpi=180)
plt.close()

hotel_counts = df["hotel"].value_counts()
plt.figure(figsize=(7, 5))
hotel_counts.plot(kind="bar")
plt.title("Bookings by Hotel Type")
plt.xlabel("Hotel")
plt.ylabel("Bookings")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(OUT_DIR / "hotel_counts.png", dpi=180)
plt.close()

# 11. EXPORT
df.to_csv(CLEAN_FILE, index=False)

summary = f"""
WEEK 1 DATA CLEANING SUMMARY
Initial shape: {pd.read_csv(RAW_FILE).shape}
Final shape: {df.shape}
Duplicate rows after cleaning: {df.duplicated().sum()}
Remaining missing cells: {df.isna().sum().sum()}
Cleaned file: {CLEAN_FILE}
"""
(OUT_DIR / "summary.txt").write_text(summary, encoding="utf-8")
print(summary)
print("Project completed successfully.")
